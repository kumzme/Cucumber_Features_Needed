/**
 * Created by DM on 12/25/2016.
 */

function getTheChartsReady(){
    var ctx = document.getElementById("myChart");
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
            datasets: [{
                label: '# of Votes',
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255,99,132,1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });
};

$( document ).ready(function() {
    $(".acollection-item*").click(function() {
        console.log("came in");
        $('.dummy').hide();
    });
    $('.collapsible').collapsible();
    getTheChartsReady();


    $(".collection-item*").click(function(){

        current_id = $(this).attr('id').toString();
        console.log(current_id);
        if ( current_id !== "show_All"){
            $('.collapsible').hide();
            console.log($(this).attr('id').toString().replace("show_",""));
            $(  '#item_' +
                current_id.replace("show_","")
            ).show();
        }
        else {
            $('.collapsible').show();
            console.log("jiahaa");
        }
    });


});

$('.collapsible').collapsible();



//
// <div class="buttons">
//     <a  id="showall">All</a>
//     <a  class="showSingle" target="1">Div 1</a>
// <a  class="showSingle" target="2">Div 2</a>
// <a  class="showSingle" target="3">Div 3</a>
// <a  class="showSingle" target="4">Div 4</a>
// </div>
//
// <div id="div1" class="targetDiv">Lorum Ipsum1</div>
// <div id="div2" class="targetDiv">Lorum Ipsum2</div>
// <div id="div3" class="targetDiv">Lorum Ipsum3</div>
// <div id="div4" class="targetDiv">Lorum Ipsum4</div>

// require 'cgi'
// require 'rubygems' rescue nil
// require 'nokogiri'
//
// file_path = "your_page.html"
// doc = Nokogiri::HTML(open(file_path))
// doc.css("a").each do |link|
// link.attributes["href"].value = "http://myproxy.com/?url=#{CGI.escape link.attributes["href"].value}"
// end
// doc.write_to(open(file_path, 'w'))


// jQuery(function(){
//     jQuery('#showall').click(function(){
//         jQuery('.targetDiv').show();
//     });
//     jQuery('.showSingle').click(function(){
//         jQuery('.targetDiv').hide();
//         jQuery('#div'+$(this).attr('target')).show();
//     });
// });